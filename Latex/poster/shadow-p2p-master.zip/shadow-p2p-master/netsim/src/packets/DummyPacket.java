package packets;

import java.util.UUID;


public class DummyPacket extends Packet{

    public DummyPacket(UUID destination) {
        super(destination);
        // TODO Auto-generated constructor stub
    }


}
