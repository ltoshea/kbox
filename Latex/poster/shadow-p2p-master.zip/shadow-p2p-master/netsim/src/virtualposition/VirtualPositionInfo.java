package virtualposition;

import java.awt.Point;
import java.util.UUID;

public class VirtualPositionInfo {
    public Point virtualPosition;
    public UUID north;
    public UUID east;
}
